from typing import Dict
from kraken.common.app_config.config import Config
from kraken.utils import cli
from .versions import *


def render_from_config(config, kind_filter=None):
    # type: (Config, list) -> Dict[str, dict]
    """ Render k8s templates from app config

    :param config:
    :param kind_filter:
    :return:
    """
    if config.version == '1.0':
        return v1_0.render_config_templates(config, kind_filter)

    cli.abort(f'unsupported config version {config.version}')

import sys


def info(msg):
    """ Print info message to stdout

    :param msg:
    :return:
    """
    sys.stdout.write(f'{msg}\n')


def error(msg):
    """ Print out error message to stderr

    :param msg:
    :return:
    """
    sys.stderr.write(f'error: {msg}\n')


def abort(msg, exit_code=1):
    """ Print error message and terminate application

    :param msg:
    :param exit_code:
    :return:
    """
    error(msg)
    exit(exit_code)
